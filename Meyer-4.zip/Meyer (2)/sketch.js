//Welcome to my retro TV! It has some cool features.

//initializing variables
let screenGreen = 30;
let screenBlue = 0;
let screenRed = 0;
let powButtonColor = 180;
let powLightColor = 0;
let tapeSlotColor = 180;
let pauseButtonColor = 180;


function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(80);
  //set color and created the necessary shapes
  colorMode(RGB);
  fill(screenRed, screenGreen, screenBlue);
  rect(50, 50, 400, 250);
  
  fill(tapeSlotColor);
  rect(50, 350, 250, 50);
  
  fill(powButtonColor);
  rect(400, 350, 20, 20);
  
  fill(powLightColor, 0, 0);
  ellipse(430, 360, 5, 5);
  
  //Connect color of screen to whether or not the TV is on
  if(powButtonColor == 90){
    screenGreen = 100;
  }
  else{
    screenGreen = 30;
  }
  //Setting up the pause button
  fill(pauseButtonColor);
  ellipseMode(RADIUS);
  ellipse(350, 400, 30, 30);
  //Connected power button light to whether or not the power button is pressed
  if(powButtonColor == 90){
    powLightColor = 255;
  }
  else{
    powLightColor = 0;
  }
  
  //Checks to see if screen is displaying "images" and whether or not there is a tape in or the power is off (As you can't play a tape if the machine is off or if there isn't a tape)
  
  if(screenRed, screenGreen, screenBlue != 0 && powButtonColor === 180){
    
    screenRed = 0;
    screenGreen = 30;
    screenBlue = 0;
  }
  
  else if(screenRed, screenGreen, screenBlue != 0 && tapeSlotColor === 180 && powButtonColor === 90){
    
    screenRed = 0;
    screenGreen = 100;
    screenBlue = 0;
    
  }
  
  
}

function mouseClicked() {
  
  //Set parameters for clicking and whatnot
  
  
  //SIDE NOTE: No more seizure inducing lights with this new code! Yay!
  if(dist(mouseX, mouseY, 350, 400)<= 30 && powButtonColor === 90 && tapeSlotColor === 0){
    screenRed = random(0, 255);
    screenGreen = random(0, 255);
    screenBlue = random(0, 255);
  }
  if(mouseX >=400 && mouseX <= 420 && mouseY >= 350 && mouseY <= 370){
  if (powButtonColor === 180) {
    powButtonColor = 90;
  } else {
    powButtonColor = 180;
  }
  }
  
  
  if(mouseX >= 50 && mouseX <= 300 && mouseY >= 350 && mouseY <= 400 && keyIsPressed === true){
  if (tapeSlotColor === 180) {
    tapeSlotColor = 0;
  } else {
    tapeSlotColor = 180;
  }
  }
  
}