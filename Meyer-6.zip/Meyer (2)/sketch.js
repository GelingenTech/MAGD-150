//the scene is putting candy in a halloween bucket

let vet = [1, 5, 6, 7];
function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  colorMode(RGB);
  print(vet.length);
  background(220);
  let ary = [];
  for(let x = 0; x < 10; x++){
    vet[x] = x;
  }
  vet[x = 1] = mouseX;
  vet[x = 2] = mouseY;
  print(vet);
  stroke(2, 50, 3);
  fill(250, 10, 30);
  
  //candy
  ellipse(vet[1], vet[2], 50, 50);
  
  fill(250, 165, 0);
  //Halloween bucket
  rect(200, 200, 100, 100);
  
  
  stroke(250, 165, 0);
  strokeWeight(2);
  noFill();
  //Halloween bucket handle
  ellipse(250, 200, 100, 80);
  
rect(245, 280, 10, 10);
  fill(0);
  stroke(0);
  triangle(225, 220, 210, 250, 240, 250);
  triangle(275, 220, 290, 250, 260, 250);
  
  ellipse(250, 280, 80, 30);
  
  
  
  fill(250, 165, 0);
  noStroke();
  rect(245, 286, 20, 10);
  rect(220, 260, 15, 17);
  
}