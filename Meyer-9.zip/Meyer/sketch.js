function setup() {
  noCanvas();
  vid = createVideo(
    ['listeningToMusic.mp4', 'sample_1280x720.ogv', 'tramMOVIN.webm'],
    vidLoad
  );
  
  vid.size(1920, 1080);
}

function draw() {
 
}

function vidLoad() {
  vid.loop();
  vid.volume(0);
}